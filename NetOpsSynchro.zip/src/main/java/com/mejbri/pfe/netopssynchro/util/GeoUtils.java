package com.mejbri.pfe.netopssynchro.util;

public final class GeoUtils {

    private static final double EARTH_RADIUS_KM = 6371.0;
    private static final double AVG_SPEED_KMH   = 45.0;

    private GeoUtils() {}

    public static double distanceKm(double lat1, double lon1,
                                    double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return EARTH_RADIUS_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    public static double travelMinutes(double distanceKm) {
        return (distanceKm / AVG_SPEED_KMH) * 60.0;
    }

    public static double travelMinutes(double lat1, double lon1,
                                       double lat2, double lon2) {
        return travelMinutes(distanceKm(lat1, lon1, lat2, lon2));
    }
}
